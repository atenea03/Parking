fx_version 'bodacious'
games { 'gta5' }

author 'Atenea'
description 'Para Ti <3'
version '1.0.1'

this_is_a_map 'yes'
